extern int toy_printf(char *fs, ...); 
